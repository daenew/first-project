from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from flask import (
    Flask, request, redirect, url_for, render_template_string, flash,
    send_from_directory, session, jsonify
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename


# ============================================================
# Config
# ============================================================
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "ai_bank_mvp_v2.sqlite3"

UPLOAD_DIR = BASE_DIR / "uploads_ai_bank"
UPLOAD_DIR.mkdir(exist_ok=True)

QIMG_DIR = UPLOAD_DIR / "qimg"
QIMG_DIR.mkdir(exist_ok=True)

ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin1234")

ALLOWED_IMG_EXT = {"png", "jpg", "jpeg", "webp"}


def allowed_image(filename: str) -> bool:
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in ALLOWED_IMG_EXT


# ============================================================
# Curriculum-ish subject taxonomy (너의 서비스용 표준값)
# - 지금은 “기본”만 박아두고, 나중에 필요하면 확장
# ============================================================
GRADES = ["중1", "중2", "중3", "고1", "고2"]
SUBJECT_GROUPS = ["사회", "과학"]

# 고등은 세부과목이 사실상 필요(통합/한국사/선택 등)
HIGH_SUBJECTS = {
    "사회": ["통합사회1", "통합사회2", "한국사1", "한국사2", "생활과 윤리", "사회문화", "정치와 법", "윤리와 사상", "한국지리"],
    "과학": ["통합과학1", "통합과학2", "물리학Ⅰ", "지구과학Ⅰ", "생명과학Ⅰ", "화학Ⅰ"],
}

# 중등은 단순히 “사회/과학”으로도 운영 가능(세부는 옵션)
MIDDLE_SUBJECTS = {
    "사회": ["사회①","사회②","역사①", "역사②"],
    "과학": ["과학"],
}


def school_level(grade: str) -> str:
    return "high" if grade.startswith("고") else "middle"


# ============================================================
# Difficulty mix
# - 사용자 UI는 1~5 “목표 난이도”
# - DB는 difficulty_level 1~5로 저장
# - 추출 시 목표 난이도에 맞춰 비율 믹스
# ============================================================
def level_to_label(lv: int) -> str:
    if lv <= 2:
        return "easy"
    if lv == 3:
        return "medium"
    return "hard"


# =========================
# Difficulty mix (new)
# - UI: 프리셋 선택 + (옵션) 커스텀 비율
# - 서버: easy/medium/hard 비율로 qe/qm/qh 산출
# =========================

# 프리셋(퍼센트)
MIX_PRESET_V2 = {
    "review":    (50, 40, 10),  # 개념 복습형
    "balanced":  (20, 60, 20),  # 기본 균형형 (기본값)
    "exam":      (10, 50, 40),  # 실전 대비형
    "challenge": (5,  25, 70),  # 도전형(고난도)
}

MIX_PRESET_LABEL_KO = {
    "review": "개념 복습형",
    "balanced": "기본 균형형",
    "exam": "실전 대비형",
    "challenge": "도전형(고난도)",
}

def _normalize_mix(e: int, m: int, h: int) -> tuple[int, int, int]:
    # 음수 방지 + 합계 100 맞춤
    e = max(0, int(e)); m = max(0, int(m)); h = max(0, int(h))
    s = e + m + h
    if s <= 0:
        return MIX_PRESET_V2["balanced"]
    # 비율 합이 100이 아니면 100으로 정규화(반올림 포함)
    e2 = int(round(e * 100 / s))
    m2 = int(round(m * 100 / s))
    h2 = 100 - e2 - m2
    if h2 < 0:
        # m에서 깎아서 보정
        take = min(m2, -h2)
        m2 -= take
        h2 += take
    # 여전히 합이 100 안 맞으면 m로 미세보정
    while e2 + m2 + h2 < 100:
        m2 += 1
    while e2 + m2 + h2 > 100 and m2 > 0:
        m2 -= 1
    return e2, m2, h2

def quota_v2(count: int, e_pct: int, m_pct: int, h_pct: int) -> tuple[int, int, int]:
    e_pct, m_pct, h_pct = _normalize_mix(e_pct, m_pct, h_pct)
    qe = int(round(count * (e_pct / 100)))
    qm = int(round(count * (m_pct / 100)))
    qh = count - qe - qm
    if qh < 0:
        qh = 0
    # 합계 보정(반올림 오차)
    while qe + qm + qh < count:
        qm += 1
    while qe + qm + qh > count and qm > 0:
        qm -= 1
    return qe, qm, qh



# ============================================================
# Flask / DB
# ============================================================
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024

db = SQLAlchemy(app)


class Question(db.Model):
    __tablename__ = "question"

    id = db.Column(db.Integer, primary_key=True)

    grade = db.Column(db.String(10), nullable=False)               # 중1~고3
    subject_group = db.Column(db.String(10), nullable=False)       # 사회/과학
    sub_subject = db.Column(db.String(40), nullable=True)          # 통합사회/통합과학/한국사/물리학...
    unit = db.Column(db.String(200), nullable=False)               # 단원(체크박스 기준)

    qtype = db.Column(db.String(10), nullable=False, default="essay")  # essay/mcq/short
    question = db.Column(db.Text, nullable=False)
    choices_json = db.Column(db.Text, nullable=True)              # mcq 보기
    answer = db.Column(db.Text, nullable=False)
    solution = db.Column(db.Text, nullable=True)                  # 선택(교사용 메모)

    # 난이도 (1~5)
    difficulty_level = db.Column(db.Integer, nullable=False, default=3)
    difficulty_label = db.Column(db.String(10), nullable=False, default="medium")  # easy/medium/hard(편의)

    # 이미지(선택): 문제 캡쳐 등
    image_filename = db.Column(db.String(255), nullable=True)

    # pending/approved/rejected
    status = db.Column(db.String(20), nullable=False, default="pending")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ============================================================
# Templates
# ============================================================
BASE_HTML = """
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>AI 문항은행 MVP v2</title>
  <script src="{{ url_for('static', filename='curriculum.js') }}"></script>
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Apple SD Gothic Neo,Noto Sans KR,sans-serif;margin:0;background:#f6f7f9;}
    header{background:#111827;color:#fff;padding:14px 18px;display:flex;gap:12px;align-items:center;justify-content:space-between;}
    header a{color:#fff;text-decoration:none;font-weight:900;}
    .wrap{max-width:1100px;margin:0 auto;padding:18px;}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;}
    .muted{color:#6b7280;font-size:13px;}
    .flash{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;padding:10px 12px;border-radius:10px;margin:12px 0;}
    .btn{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid #d1d5db;background:#fff;cursor:pointer;font-weight:900;text-decoration:none;color:#111;}
    .btn.primary{background:#2563eb;border-color:#2563eb;color:#fff;}
    .btn.success{background:#16a34a;border-color:#16a34a;color:#fff;}
    .btn.danger{background:#dc2626;border-color:#dc2626;color:#fff;}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
    input,select,textarea{width:100%;padding:10px;border:1px solid #d1d5db;border-radius:10px;}
    textarea{min-height:140px;}
    table{width:100%;border-collapse:collapse;}
    th,td{border-bottom:1px solid #eee;padding:10px;text-align:left;vertical-align:top;font-size:14px;}
    th{background:#fafafa;font-size:13px;color:#374151;}
    .pill{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;border:1px solid #e5e7eb;background:#fff;margin-right:4px;}
    .qbox{white-space:pre-wrap; line-height:1.45;}
    .chips{display:flex;gap:8px;flex-wrap:wrap;}
    .chip{padding:8px 10px;border:1px solid #d1d5db;border-radius:999px;background:#fff;cursor:pointer;font-weight:800;}
    .chip input{display:none;}
    .chip.active{border-color:#2563eb;color:#2563eb;}
    .unitlist{max-height:240px;overflow:auto;border:1px solid #e5e7eb;border-radius:10px;padding:10px;background:#fafafa;}
    .unititem{display:flex;gap:8px;align-items:flex-start;margin:6px 0;}
    .unititem input{width:auto;margin-top:3px;}
    .imgbox{margin-top:8px;}
    .imgbox img{max-width:560px;width:100%;border:1px solid #eee;border-radius:10px;}
    @media (max-width: 900px){ .row{grid-template-columns:1fr;} }
    /* ===== Review action buttons (approve/reject/delete) ===== */
    .table-review{
      width:100%;
      border-collapse:collapse;
    }
    .table-review th,
    .table-review td{
      text-align:center;           /* ✅ 기본 가운데 정렬 */
      vertical-align:middle;
    }
    /* 문항 펼쳤을 때 내용은 읽기 좋게 좌측 정렬 */
    .table-review td.col-question details,
    .table-review td.col-question .qbox{
      text-align:left;
    }
    .review-actions{
      display:flex;
      gap:10px;
      align-items:center;
      justify-content:center; /* ✅ 조치 열의 버튼을 가운데로 */
      flex-wrap:nowrap;
    }

    .review-actions form{
      display:flex;
      gap:8px;
      margin:0;
    }

    /* 버튼 크기/톤 통일 (기존 .btn보다 조금 더 컴팩트) */
    .review-actions .btn{
      padding:8px 12px;
      border-radius:10px;
      font-size:13px;
      font-weight:900;
      line-height:1;
      border:1px solid transparent;
    }

    /* 승인: 딥그린 (기존 success보다 덜 쨍하게) */
    .btn-approve{
      background:#1f8f5f;
      border-color:#1f8f5f;
      color:#fff;
    }
    .btn-approve:hover{ background:#18724c; border-color:#18724c; }

    /* 반려: 브릭 레드 (기존 danger보다 덜 자극적으로) */
    .btn-reject{
      background:#c94a4a;
      border-color:#c94a4a;
      color:#fff;
    }
    .btn-reject:hover{ background:#a63c3c; border-color:#a63c3c; }

    /* 삭제: 아웃라인 (위험하지만 과하게 튀지 않게) */
    .btn-delete{
      background:#fff;
      border-color:#c94a4a;
      color:#c94a4a;
    }
    .btn-delete:hover{
      background:#c94a4a;
      color:#fff;
    }

    /* 테이블 좁아질 때 버튼 줄바꿈 방지(필요시) */
    td .review-actions{ min-width: 240px; }

    /* ✅ 조치 열(헤더/셀) 강제 가운데 정렬 */
    .table-review th.col-actions,
    .table-review td.col-actions{
      text-align:center;
    }
    
    /* ===== Difficulty mix advanced compact ===== */
    .mix-advanced { margin-top:10px; }

    .mix-advanced summary{
      list-style:none;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:10px;
      padding:10px 12px;
      border:1px solid #e5e7eb;
      border-radius:12px;
      background:#fafafa;
      cursor:pointer;
      font-weight:900;
    }
    .mix-advanced summary::-webkit-details-marker{ display:none; }

    .mix-advanced .sum-title{ white-space:nowrap; }
    .mix-advanced .sum-values{ font-weight:700; color:#374151; }
    .mix-advanced .sum-hint{
      font-size:12px; font-weight:900;
      padding:6px 10px; border-radius:999px;
      border:1px solid #d1d5db; background:#fff;
    }

    .mix-sliders{
      margin-top:10px;
      display:grid;
      gap:10px;
    }

    .mix-row{
      display:grid;
      grid-template-columns:70px 1fr 52px;
      align-items:center;
      gap:10px;
    }
    .mix-row .label{ color:#6b7280; font-weight:800; font-size:13px; }
    .mix-row .value{ text-align:right; font-weight:900; color:#111827; }
    .mix-row input[type="range"]{ width:100%; margin:0; }

    .row.row-compact{
      display:grid;
      grid-template-columns: 1fr 240px;
      gap:12px;
      align-items:start;
    }

    .row.row-compact{
      display:block;
    }

    /* 두 입력 블록의 기준 폭 통일 */
    .col-subject,
    .col-count{
      width:150px;
      max-width:100%;
      display:flex;
      flex-direction:column;
      gap:6px;
    }

    /* label / input 동일 폭 */
    .col-subject label,
    .col-count label,
    .col-subject select,
    .col-count input{
      width:100%;
      box-sizing:border-box;
    }

    /* 모바일 */
    @media (max-width:900px){
      .col-subject,
      .col-count{
        width:100%;
      }
    }


  </style>
</head>
<body>
<header>
  <div style="display:flex;gap:12px;align-items:center;">
    <a href="{{ url_for('home') }}">AI 문항은행 MVP v2</a>
    <a class="btn" style="padding:8px 10px;" href="{{ url_for('worksheet') }}">사용자: 학습지 생성</a>
    <a class="btn" style="padding:8px 10px;" href="{{ url_for('admin_home') }}">관리자</a>
  </div>
  <div class="muted" style="color:#cbd5e1;">
    승인된 문항만 사용자에게 노출
  </div>
</header>

<div class="wrap">
  {% for m in get_flashed_messages() %}
    <div class="flash">{{ m }}</div>
  {% endfor %}
  {{ body|safe }}
</div>
</body>
</html>
"""


# ============================================================
# Auth (admin)
# ============================================================
def admin_required() -> bool:
    return session.get("is_admin") is True


@app.route("/")
def home():
    approved = Question.query.filter_by(status="approved").count()
    pending = Question.query.filter_by(status="pending").count()
    rejected = Question.query.filter_by(status="rejected").count()

    body = """
    <div class="card">
      <h2 style="margin:0 0 10px;">현재 상태</h2>
      <div class="muted">사용자 친화적 선택 UI(학년/과목 토글 + 단원 체크 + 목표 난이도 믹스) 적용 버전</div>

      <div style="margin-top:12px;">
        <span class="pill">approved: {{ approved }}</span>
        <span class="pill">pending: {{ pending }}</span>
        <span class="pill">rejected: {{ rejected }}</span>
      </div>

      <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;">
        <a class="btn primary" href="{{ url_for('worksheet') }}">사용자: 학습지 생성</a>
        <a class="btn" href="{{ url_for('admin_home') }}">관리자 페이지</a>
      </div>

      <hr style="border:none;border-top:1px solid #eee;margin:16px 0;" />

      <div class="muted">
        ✅ 이미지 문제: 관리자 문항 등록 시 JPG/PNG 업로드 가능 → 학습지에서도 텍스트 문제와 함께 자연스럽게 섞여 출력됨
      </div>
    </div>
    """
    return render_template_string(BASE_HTML, body=render_template_string(
        body, approved=approved, pending=pending, rejected=rejected
    ))


# ============================================================
# Static file serving (question images)
# ============================================================
@app.route("/uploads/qimg/<path:filename>")
def qimg(filename: str):
    return send_from_directory(str(QIMG_DIR), filename, as_attachment=False)


# ============================================================
# Admin
# ============================================================
@app.route("/admin", methods=["GET"])
def admin_home():
    if not admin_required():
        return redirect(url_for("admin_login"))

    body = """
    <div class="card">
      <h2 style="margin:0 0 10px;">관리자</h2>

      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:12px 0;">
        <a class="btn primary" href="{{ url_for('admin_new_question') }}">문항 등록</a>
        <a class="btn" href="{{ url_for('admin_bulk_import') }}">일괄등록(JSONL)</a>
        <a class="btn" href="{{ url_for('admin_review') }}">검수(승인/반려)</a>
        <a class="btn danger" href="{{ url_for('admin_logout') }}">로그아웃</a>
      </div>

      <div class="muted">
        - 사용자 화면은 텍스트 입력이 아니라 선택 UI 기반입니다. (학년/과목 토글 + 단원 체크)<br/>
        - 따라서 관리자도 메타데이터(학년/과목군/단원)를 정확히 넣는 게 중요합니다.
      </div>
    </div>
    """
    return render_template_string(BASE_HTML, body=render_template_string(body))


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        pw = (request.form.get("password") or "").strip()
        if pw == ADMIN_PASSWORD:
            session["is_admin"] = True
            flash("관리자 로그인 완료")
            return redirect(url_for("admin_home"))
        flash("비밀번호가 올바르지 않습니다.")
        return redirect(url_for("admin_login"))

    body = """
    <div class="card" style="max-width:520px;">
      <h2 style="margin:0 0 10px;">관리자 로그인</h2>
      <form method="post" style="display:grid;gap:10px;">
        <div>
          <label class="muted">비밀번호</label>
          <input name="password" type="password" placeholder="관리자 비밀번호" required />
        </div>
        <button class="btn primary" type="submit">로그인</button>
        <div class="muted">기본 비밀번호: admin1234 (환경변수 ADMIN_PASSWORD로 변경 가능)</div>
      </form>
    </div>
    """
    return render_template_string(BASE_HTML, body=render_template_string(body))


@app.route("/admin/logout")
def admin_logout():
    session.clear()
    flash("로그아웃 완료")
    return redirect(url_for("home"))


@app.route("/admin/questions/new", methods=["GET", "POST"])
def admin_new_question():
    if not admin_required():
        return redirect(url_for("admin_login"))

    if request.method == "POST":
        grade = (request.form.get("grade") or "").strip()
        subject_group = (request.form.get("subject_group") or "").strip()
        sub_subject = (request.form.get("sub_subject") or "").strip() or None
        unit = (request.form.get("unit") or "").strip()

        qtype = (request.form.get("qtype") or "essay").strip()
        qtext = (request.form.get("question") or "").strip()
        answer = (request.form.get("answer") or "").strip()
        solution = (request.form.get("solution") or "").strip() or None

        difficulty_level = int(request.form.get("difficulty_level") or 3)
        difficulty_level = max(1, min(5, difficulty_level))
        difficulty_label = level_to_label(difficulty_level)

        choices_json = None
        if qtype == "mcq":
            # 보기 입력(줄바꿈으로 1줄=1보기)
            raw_choices = (request.form.get("choices") or "").strip()
            choices = [c.strip() for c in raw_choices.splitlines() if c.strip()]
            if len(choices) < 3:
                flash("객관식 보기는 최소 3개 이상 입력하세요.")
                return redirect(url_for("admin_new_question"))
            choices_json = json.dumps(choices, ensure_ascii=False)

        if grade not in GRADES:
            flash("학년 값이 올바르지 않습니다.")
            return redirect(url_for("admin_new_question"))
        if subject_group not in SUBJECT_GROUPS:
            flash("과목군 값이 올바르지 않습니다.")
            return redirect(url_for("admin_new_question"))
        if not unit or not qtext or not answer:
            flash("단원/문항/정답은 필수입니다.")
            return redirect(url_for("admin_new_question"))

        # 이미지 업로드(선택)
        image_filename = None
        img = request.files.get("image")
        if img and img.filename:
            if not allowed_image(img.filename):
                flash("이미지 허용 확장자: png, jpg, jpeg, webp")
                return redirect(url_for("admin_new_question"))
            safe = secure_filename(img.filename)
            stamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
            ext = safe.rsplit(".", 1)[1].lower()
            image_filename = f"{stamp}_{safe.rsplit('.',1)[0]}.{ext}"
            img.save(str(QIMG_DIR / image_filename))

        q = Question(
            grade=grade,
            subject_group=subject_group,
            sub_subject=sub_subject,
            unit=unit,
            qtype=qtype,
            question=qtext,
            choices_json=choices_json,
            answer=answer,
            solution=solution,
            difficulty_level=difficulty_level,
            difficulty_label=difficulty_label,
            image_filename=image_filename,
            status="pending",
        )
        db.session.add(q)
        db.session.commit()
        flash(f"문항 등록 완료 (pending) / ID={q.id}")
        return redirect(url_for("admin_review"))

    body = """
    <div class="card">
      <h2 style="margin:0 0 10px;">문항 등록</h2>
      <div class="muted">이미지 문제는 JPG/PNG 캡쳐 업로드 가능(선택). 승인 후 사용자 학습지에 그대로 반영됩니다.</div>

      <form method="post" enctype="multipart/form-data" style="display:grid;gap:12px;margin-top:12px;">
        <div class="row">
          <div>
            <label class="muted">학년</label>
            <select name="grade" required>
              {% for g in GRADES %}<option value="{{g}}">{{g}}</option>{% endfor %}
            </select>
          </div>
          <div>
            <label class="muted">과목군</label>
            <select name="subject_group" id="subject_group" required>
              {% for sg in SUBJECT_GROUPS %}<option value="{{sg}}">{{sg}}</option>{% endfor %}
            </select>
          </div>
        </div>

        <div class="row">
          <div>
            <label class="muted">세부과목(고등 추천)</label>
            <select name="sub_subject" id="sub_subject">
              <option value="">(선택)</option>
            </select>
            <div class="muted" style="margin-top:6px;">중등은 비워도 운영 가능 / 고등은 통합사회·한국사·통합과학 등 구분 추천</div>
          </div>

          <div>
            <label class="muted">단원(대단원/소단원)</label>
            <div class="row" style="grid-template-columns: 1fr 1fr;">
              <div>
                <select id="big_unit_sel">
                  <option value="">대단원 선택</option>
                </select>
              </div>
              <div>
                <select id="small_unit_sel">
                  <option value="">소단원 선택</option>
                </select>
              </div>
            </div>

            <!-- ✅ 실제 DB 저장값 -->
            <input type="hidden" name="unit" id="unit_hidden" required />

            <div class="muted" style="margin-top:6px;">
              저장 형식: <b>대단원 &gt; 소단원</b> (커리큘럼은 static/curriculum.js에서 관리)
            </div>
          </div>
        </div>


        <div class="row">
          <div>
            <label class="muted">문항 유형</label>
            <select name="qtype" id="qtype">
              <option value="essay" selected>서술형(essay)</option>
              <option value="mcq">객관식(mcq)</option>
              <option value="short">단답형(short)</option>
            </select>
          </div>
          <div>
            <label class="muted">난이도 레벨(1~5)</label>
            <input type="number" name="difficulty_level" min="1" max="5" value="3" />
          </div>
        </div>

        <div id="mcq_choices_wrap" style="display:none;">
          <label class="muted">객관식 보기(줄바꿈으로 1줄=1보기)</label>
          <textarea name="choices" placeholder="보기1&#10;보기2&#10;보기3"></textarea>
        </div>

        <div class="row">
          <div>
            <label class="muted">문항(텍스트)</label>
            <textarea name="question" required></textarea>
          </div>
          <div>
            <label class="muted">정답(확정형으로 입력)</label>
            <textarea name="answer" required></textarea>
            <div class="muted" style="margin-top:6px;">서술형도 ‘가이드’가 아니라 정답 문장 그대로 넣고, 관리자가 승인/반려합니다.</div>
          </div>
        </div>

        <div>
          <label class="muted">해설/메모(선택)</label>
          <textarea name="solution" placeholder="(선택) 교사용 메모/해설"></textarea>
        </div>

        <div>
          <label class="muted">문제 이미지 업로드(선택)</label>
          <input type="file" name="image" accept=".png,.jpg,.jpeg,.webp" />
          <div class="muted">※ 문제집 캡쳐한 JPG를 올리면 문항에 이미지가 붙고, 학습지에서도 같이 출력됩니다.</div>
        </div>

        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <button class="btn primary" type="submit">등록(pending)</button>
          <a class="btn" href="{{ url_for('admin_home') }}">관리자 홈</a>
        </div>
      </form>
    </div>

    <script>
      const GRADES = {{ GRADES|tojson }};
      const HIGH_SUBJECTS = {{ HIGH_SUBJECTS|tojson }};
      const MIDDLE_SUBJECTS = {{ MIDDLE_SUBJECTS|tojson }};

      function isHigh(grade){ return (grade || "").startsWith("고"); }

      function fillSubSubjects(){
        const grade = document.querySelector('select[name="grade"]').value;
        const sg = document.getElementById("subject_group").value;
        const ss = document.getElementById("sub_subject");
        ss.innerHTML = '<option value="">(선택)</option>';

        const data = isHigh(grade) ? HIGH_SUBJECTS : MIDDLE_SUBJECTS;
        (data[sg] || []).forEach(v=>{
          const o = document.createElement("option");
          o.value = v; o.textContent = v;
          ss.appendChild(o);
        });
      }

      function toggleMcq(){
        const qt = document.getElementById("qtype").value;
        document.getElementById("mcq_choices_wrap").style.display = (qt === "mcq") ? "block" : "none";
      }

      // ✅ 커리큘럼 기반 대/소단원 채우기
      const bigSel = document.getElementById("big_unit_sel");
      const smallSel = document.getElementById("small_unit_sel");
      const unitHidden = document.getElementById("unit_hidden");

      function fillUnits(){
        if (!window.getCurriculumBlocks || !window.formatUnitValue) {
          unitHidden.value = "";
          bigSel.innerHTML = '<option value="">대단원 선택</option>';
          smallSel.innerHTML = '<option value="">소단원 선택</option>';
          return;
        }

        const grade = document.querySelector('select[name="grade"]').value;
        const sg = document.getElementById("subject_group").value;
        const ss = (document.getElementById("sub_subject").value || "").trim();

        const blocks = window.getCurriculumBlocks(grade, sg, ss);

        bigSel.innerHTML = '<option value="">대단원 선택</option>';
        smallSel.innerHTML = '<option value="">소단원 선택</option>';
        unitHidden.value = "";

        blocks.forEach((b, idx)=>{
          const o = document.createElement("option");
          o.value = String(idx);
          o.textContent = b.big;
          bigSel.appendChild(o);
        });
      }

      function fillSmallUnits(){
        const grade = document.querySelector('select[name="grade"]').value;
        const sg = document.getElementById("subject_group").value;
        const ss = (document.getElementById("sub_subject").value || "").trim();
        const blocks = window.getCurriculumBlocks(grade, sg, ss);

        const idx = parseInt(bigSel.value || "-1", 10);
        smallSel.innerHTML = '<option value="">소단원 선택</option>';
        unitHidden.value = "";

        if (idx < 0 || idx >= blocks.length) return;

        const block = blocks[idx];
        (block.small || []).forEach(s=>{
          const o = document.createElement("option");
          o.value = s;
          o.textContent = s;
          smallSel.appendChild(o);
        });

        // 대단원만 선택해도 저장되게(소단원 선택은 옵션)
        unitHidden.value = window.formatUnitValue(block.big, "");
      }

      function syncUnitHidden(){
        const grade = document.querySelector('select[name="grade"]').value;
        const sg = document.getElementById("subject_group").value;
        const ss = (document.getElementById("sub_subject").value || "").trim();
        const blocks = window.getCurriculumBlocks(grade, sg, ss);

        const idx = parseInt(bigSel.value || "-1", 10);
        if (idx < 0 || idx >= blocks.length) { unitHidden.value = ""; return; }
        const big = blocks[idx].big;
        const small = (smallSel.value || "");
        unitHidden.value = window.formatUnitValue(big, small);
      }

      document.querySelector('select[name="grade"]').addEventListener("change", ()=>{
        fillSubSubjects();
        fillUnits();
      });
      document.getElementById("subject_group").addEventListener("change", ()=>{
        fillSubSubjects();
        fillUnits();
      });
      document.getElementById("sub_subject").addEventListener("change", ()=>{
        fillUnits();
      });

      bigSel.addEventListener("change", ()=>{
        fillSmallUnits();
        syncUnitHidden();
      });
      smallSel.addEventListener("change", syncUnitHidden);

      document.getElementById("qtype").addEventListener("change", toggleMcq);

      // 초기화
      fillSubSubjects();
      toggleMcq();
      fillUnits();
    </script>

    """
    return render_template_string(BASE_HTML, body=render_template_string(
        body, GRADES=GRADES, SUBJECT_GROUPS=SUBJECT_GROUPS,
        HIGH_SUBJECTS=HIGH_SUBJECTS, MIDDLE_SUBJECTS=MIDDLE_SUBJECTS
    ))


@app.route("/admin/questions/bulk", methods=["GET", "POST"])
def admin_bulk_import():
    if not admin_required():
        return redirect(url_for("admin_login"))

    if request.method == "POST":
        raw = (request.form.get("jsonl") or "").strip()
        if not raw:
            flash("JSONL을 입력하세요.")
            return redirect(url_for("admin_bulk_import"))

        created = 0
        failed = 0
        errors = []

        for idx, line in enumerate(raw.splitlines(), start=1):
            ln = line.strip()
            if not ln:
                continue
            try:
                obj = json.loads(ln)

                grade = (obj.get("grade") or "").strip()
                subject_group = (obj.get("subject_group") or "").strip()
                sub_subject = (obj.get("sub_subject") or None)
                unit = (obj.get("unit") or "").strip()
                qtype = (obj.get("qtype") or "essay").strip()
                qtext = (obj.get("question") or "").strip()
                answer = (obj.get("answer") or "").strip()
                solution = (obj.get("solution") or None)

                difficulty_level = int(obj.get("difficulty_level") or 3)
                difficulty_level = max(1, min(5, difficulty_level))
                difficulty_label = level_to_label(difficulty_level)

                choices_json = None
                if qtype == "mcq":
                    choices = obj.get("choices") or []
                    if not isinstance(choices, list) or len(choices) < 3:
                        raise ValueError("mcq choices는 list(3개 이상)여야 함")
                    choices_json = json.dumps(choices, ensure_ascii=False)

                # 이미지 파일명(선택): 이미 QIMG_DIR에 업로드되어 있다고 가정
                image_filename = obj.get("image_filename") or None

                if grade not in GRADES:
                    raise ValueError("grade invalid")
                if subject_group not in SUBJECT_GROUPS:
                    raise ValueError("subject_group invalid")
                if not unit or not qtext or not answer:
                    raise ValueError("unit/question/answer required")

                q = Question(
                    grade=grade,
                    subject_group=subject_group,
                    sub_subject=sub_subject,
                    unit=unit,
                    qtype=qtype,
                    question=qtext,
                    choices_json=choices_json,
                    answer=answer,
                    solution=solution,
                    difficulty_level=difficulty_level,
                    difficulty_label=difficulty_label,
                    image_filename=image_filename,
                    status="pending",
                )
                db.session.add(q)
                created += 1
            except Exception as e:
                failed += 1
                if len(errors) < 8:
                    errors.append(f"[line {idx}] {str(e)}")

        db.session.commit()
        msg = f"일괄 등록 완료: 생성 {created} / 실패 {failed} (모두 pending)"
        if errors:
            msg += " | 실패 일부: " + " | ".join(errors)
        flash(msg)
        return redirect(url_for("admin_review"))

    body = """
    <div class="card">
      <h2 style="margin:0 0 10px;">일괄등록(JSONL)</h2>
      <div class="muted">한 줄에 1문항 JSON 객체(JSONL). 배열 JSON([..])은 안 됩니다.</div>

      <form method="post" style="display:grid;gap:12px;margin-top:12px;">
        <textarea name="jsonl" placeholder='{"grade":"중1","subject_group":"사회","unit":"1단원 ...","qtype":"essay","question":"...","answer":"...","difficulty_level":3}'></textarea>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <button class="btn primary" type="submit">일괄등록</button>
          <a class="btn" href="{{ url_for('admin_home') }}">관리자 홈</a>
        </div>
      </form>
    </div>
    """
    return render_template_string(BASE_HTML, body=render_template_string(body))


@app.route("/admin/review")
def admin_review():
    if not admin_required():
        return redirect(url_for("admin_login"))

    qs = Question.query.order_by(Question.created_at.desc()).limit(300).all()

    # ✅ mcq 보기 파싱(정식)
    for q in qs:
        q.choices_list = []
        if getattr(q, "qtype", None) == "mcq" and getattr(q, "choices_json", None):
            try:
                q.choices_list = json.loads(q.choices_json)
                if not isinstance(q.choices_list, list):
                    q.choices_list = []
            except Exception:
                q.choices_list = []

    body = """
    <div class="card">
      <h2 style="margin:0 0 10px;">검수(승인/반려)</h2>

      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:12px 0;">
        <a class="btn" href="{{ url_for('admin_new_question') }}">문항 등록</a>
        <a class="btn" href="{{ url_for('admin_bulk_import') }}">일괄등록</a>
        <a class="btn" href="{{ url_for('admin_home') }}">관리자 홈</a>
      </div>
      <table class="table-review">
        <colgroup>
          <col style="width:70px;">     <!-- ID -->
          <col style="width:300px;">    <!-- 메타 -->
          <col>                         <!-- ✅ 문항: 남는 폭 전부 -->
          <col style="width:80px;">    <!-- 난이도 -->
          <col style="width:80px;">    <!-- 상태 -->
          <col style="width:260px;">    <!-- 조치 -->
        </colgroup>

        <thead>
          <tr>
            <th>ID</th>
            <th>메타</th>
            <th>문항</th>
            <th>난이도</th>
            <th>상태</th>
            <th class="col-actions">조치</th>
          </tr>
        </thead>

        <tbody>
          {% for q in qs %}
          <tr>
            <td class="col-id">{{ q.id }}</td>

            <td class="col-meta">
              <div>
                <span class="pill">{{ q.grade }}</span>
                <span class="pill">{{ q.subject_group }}</span>
                {% if q.sub_subject %}<span class="pill">{{ q.sub_subject }}</span>{% endif %}
              </div>
              <div class="muted" style="margin-top:6px;">{{ q.unit }}</div>
            </td>

            <td class="col-question">
              <details>
                <summary><b>펼치기</b> <span class="muted">({{ q.qtype }})</span></summary>

                <div class="qbox" style="margin-top:8px;">{{ q.question }}</div>

                {% if q.qtype == 'mcq' and q.choices_list %}
                  <div style="margin-top:10px; padding:10px; border:1px solid #eee; border-radius:10px; background:#fafafa;">
                    <div style="font-weight:800; margin-bottom:6px;">보기</div>
                    <ol style="margin:0; padding-left:18px;">
                      {% for c in q.choices_list %}
                        <li style="margin:4px 0;">{{ c }}</li>
                      {% endfor %}
                    </ol>
                  </div>
                {% endif %}

                {% if q.image_filename %}
                  <div class="imgbox">
                    <img src="{{ url_for('qimg', filename=q.image_filename) }}" alt="question image"/>
                  </div>
                {% endif %}

                <div style="margin-top:10px;">
                  <div><b>정답</b></div>
                  <div class="qbox" style="margin-top:4px;">{{ q.answer }}</div>
                  {% if q.solution %}
                    <div class="muted" style="margin-top:8px;"><b>해설/메모</b>: {{ q.solution }}</div>
                  {% endif %}
                </div>
              </details>
            </td>

            <td class="col-diff">
              <span class="pill">Lv{{ q.difficulty_level }}</span>
            </td>

            <td class="col-status">
              {% if q.status == 'approved' %}✅ 승인됨
              {% elif q.status == 'rejected' %}⛔ 반려됨
              {% else %}⏳ 검토중
              {% endif %}
            </td>

            <td class="col-actions">
              <div class="review-actions">
                <form method="post" action="{{ url_for('admin_review_action', qid=q.id) }}">
                  <button class="btn btn-approve" name="action" value="approve">승인</button>
                  <button class="btn btn-reject" name="action" value="reject">반려</button>
                </form>

                <form method="post"
                      action="{{ url_for('admin_delete_question', qid=q.id) }}"
                      onsubmit="return confirm('정말 삭제할까요?');">
                  <button class="btn btn-delete">삭제</button>
                </form>
              </div>
            </td>
          </tr>
          {% endfor %}

          {% if not qs %}
            <tr><td colspan="6" class="muted">등록된 문항이 없습니다.</td></tr>
          {% endif %}
        </tbody>
      </table>
    </div>
    """
    return render_template_string(BASE_HTML, body=render_template_string(body, qs=qs))


@app.route("/admin/review/action/<int:qid>", methods=["POST"])
def admin_review_action(qid: int):
    if not admin_required():
        return redirect(url_for("admin_login"))

    q = Question.query.get_or_404(qid)
    action = (request.form.get("action") or "").strip()
    if action not in ("approve", "reject"):
        flash("잘못된 요청")
        return redirect(url_for("admin_review"))

    q.status = "approved" if action == "approve" else "rejected"
    db.session.commit()
    flash("처리 완료")
    return redirect(url_for("admin_review"))


@app.route("/admin/review/delete/<int:qid>", methods=["POST"])
def admin_delete_question(qid: int):
    if not admin_required():
        return redirect(url_for("admin_login"))

    q = Question.query.get_or_404(qid)

    # ✅ 이미지 파일도 같이 삭제(있으면)
    if q.image_filename:
        try:
            img_path = QIMG_DIR / q.image_filename
            if img_path.exists():
                img_path.unlink()
        except Exception:
            # 파일 삭제 실패해도 DB 삭제는 진행
            pass

    db.session.delete(q)
    db.session.commit()
    flash(f"문항 삭제 완료 / ID={qid}")
    return redirect(url_for("admin_review"))


# ============================================================
# API: unit list (사용자 단원 체크박스용)
# ============================================================
@app.route("/api/units")
def api_units():
    grade = (request.args.get("grade") or "").strip()
    subject_group = (request.args.get("subject_group") or "").strip()
    sub_subject = (request.args.get("sub_subject") or "").strip() or None

    q = Question.query.filter_by(status="approved")

    if grade:
        q = q.filter(Question.grade == grade)
    if subject_group:
        q = q.filter(Question.subject_group == subject_group)
    if sub_subject:
        q = q.filter(Question.sub_subject == sub_subject)

    units = [r[0] for r in q.with_entities(Question.unit).distinct().order_by(Question.unit.asc()).all()]
    return jsonify({"units": units})


# ============================================================
# User: worksheet builder
# - 토글/선택 UI + 단원 체크 + 목표 난이도 믹스
# - 이미지 문항도 같이 출력
# ============================================================
@app.route("/worksheet", methods=["GET", "POST"])
def worksheet():
    if request.method == "POST":
        grade = (request.form.get("grade") or "").strip()
        subject_group = (request.form.get("subject_group") or "").strip()
        sub_subject = (request.form.get("sub_subject") or "").strip() or None
        units = request.form.getlist("units")
        count = int(request.form.get("count") or 10)
        count = max(1, min(100, count))
        # --- new: mix mode / preset / custom ---
        mix_mode = (request.form.get("mix_mode") or "preset").strip()  # preset | custom
        mix_preset = (request.form.get("mix_preset") or "balanced").strip()

        # custom % (없으면 0으로 들어오므로 preset에서 대체)
        mix_easy = int(request.form.get("mix_easy") or 0)
        mix_mid  = int(request.form.get("mix_mid") or 0)
        mix_hard = int(request.form.get("mix_hard") or 0)

        # ✅ backward-compat: 옛 폼이 target_lv를 보내는 경우
        # (혹시 이전 버전 캐시/북마크)
        target_lv_legacy = int(request.form.get("target_lv") or 0)

        # preset 비율 결정
        if mix_mode == "custom":
            e_pct, m_pct, h_pct = _normalize_mix(mix_easy, mix_mid, mix_hard)
        else:
            # preset이 유효하지 않으면 balanced
            if mix_preset not in MIX_PRESET_V2:
                mix_preset = "balanced"
            e_pct, m_pct, h_pct = MIX_PRESET_V2[mix_preset]

        # 레거시 target_lv만 들어온 경우(예: mix_mode가 아예 없을 때)
        if (request.form.get("mix_mode") is None) and target_lv_legacy:
            # 기존 MIX_PRESET(1~5)을 아직 쓰고 싶으면 여기서 변환해도 됨.
            # 단, 현재 코드는 MIX_PRESET을 제거했으니 간단히 balanced로 둔다.
            pass

        # 난이도 믹스 추출
        qe, qm, qh = quota_v2(count, e_pct, m_pct, h_pct)

                # =========================
        # ✅ 승인된 문항 풀 구성
        # =========================
        base_q = Question.query.filter_by(status="approved")
        base_q = base_q.filter(Question.grade == grade)
        base_q = base_q.filter(Question.subject_group == subject_group)

        # sub_subject는 선택값이 있을 때만 필터
        if sub_subject:
            base_q = base_q.filter(Question.sub_subject == sub_subject)

        # 단원은 최소 1개 선택되어야 의미있게 동작
        if units:
            base_q = base_q.filter(Question.unit.in_(units))
        else:
            flash("단원을 1개 이상 선택하세요.")
            return redirect(url_for("worksheet"))

        pool_all = base_q.order_by(Question.id.desc()).limit(5000).all()

        # =========================
        # ✅ 난이도 풀 분리 (easy/medium/hard)
        # difficulty_level: 1~5
        # easy: 1~2 / medium: 3 / hard: 4~5
        # =========================
        pool_easy = [q for q in pool_all if (q.difficulty_level or 3) <= 2]
        pool_mid  = [q for q in pool_all if (q.difficulty_level or 3) == 3]
        pool_hard = [q for q in pool_all if (q.difficulty_level or 3) >= 4]

        def pick_from(pool, n):
            if n <= 0:
                return []
            if len(pool) <= n:
                return list(pool)
            return random.sample(pool, n)

        # =========================
        # ✅ 비율대로 추출
        # =========================
        selected = []
        selected += pick_from(pool_easy, qe)
        selected += pick_from(pool_mid,  qm)
        selected += pick_from(pool_hard, qh)

        # 부족하면 전체 풀에서 추가로 채움
        if len(selected) < count:
            used_ids = {q.id for q in selected}
            remain = [q for q in pool_all if q.id not in used_ids]
            selected += pick_from(remain, count - len(selected))

        # 너무 많으면 자름(반올림 보정)
        if len(selected) > count:
            selected = selected[:count]

        # =========================
        # ✅ 결과 화면에서 mcq 보기 출력 위해 choices_list 파싱
        # =========================
        for q in selected:
            q.choices_list = []
            if q.qtype == "mcq" and q.choices_json:
                try:
                    q.choices_list = json.loads(q.choices_json)
                    if not isinstance(q.choices_list, list):
                        q.choices_list = []
                except Exception:
                    q.choices_list = []


        return render_template_string(BASE_HTML, body=render_template_string(
            WORKSHEET_RESULT_HTML,
            grade=grade,
            subject_group=subject_group,
            sub_subject=sub_subject,
            units=units,
            mix_mode=mix_mode,
            mix_preset=mix_preset,
            mix_label=MIX_PRESET_LABEL_KO.get(mix_preset, "커스텀") if mix_mode != "custom" else "커스텀",
            e_pct=e_pct, m_pct=m_pct, h_pct=h_pct,
            qe=qe, qm=qm, qh=qh,
            items=selected
        ))


    return render_template_string(BASE_HTML, body=render_template_string(
        WORKSHEET_FORM_HTML,
        GRADES=GRADES,
        SUBJECT_GROUPS=SUBJECT_GROUPS,
        HIGH_SUBJECTS=HIGH_SUBJECTS,
        MIDDLE_SUBJECTS=MIDDLE_SUBJECTS
    ))


WORKSHEET_FORM_HTML = """
<div class="card">
  <h2 style="margin:0 0 10px;">사용자: 학습지 생성</h2>
  <div class="muted">학년/과목은 선택(토글) · 단원은 체크박스(복수) · 난이도는 목표(1~5)로 비율 믹스</div>

  <form method="post" id="wsForm" style="display:grid;gap:12px;margin-top:12px;">
    <div class="row">
      <div>
        <label class="muted">학년</label>
        <div class="chips" id="gradeChips"></div>
        <input type="hidden" name="grade" id="gradeInput" value="중1" />
      </div>
      <div>
        <label class="muted">과목군</label>
        <div class="chips" id="sgChips"></div>
        <input type="hidden" name="subject_group" id="sgInput" value="사회" />
      </div>
    </div>

    <div class="row row-compact">
      <div class="col-subject">
        <label class="muted">세부과목(고등 추천)</label>
        <!-- ✅ id="subSubjectSel" 꼭 유지 -->
        <select name="sub_subject" id="subSubjectSel">
          <option value="">(선택)</option>
        </select>
      </div>
    </div>

    <div class="row row-compact" style="margin-top:12px;">
      <div class="col-count">
        <label class="muted">문항수</label>
        <input type="number" name="count" value="18" min="1" max="100">
      </div>
    </div>



    <div>
      <label class="muted">문제 성향(난이도 비율)</label>

      <!-- 서버로 보내는 값 -->
      <input type="hidden" name="mix_mode" id="mixMode" value="preset" />

      <div class="chips" id="mixPresetChips" style="margin-top:6px;"></div>
      <input type="hidden" name="mix_preset" id="mixPresetInput" value="balanced" />

      <div class="muted" style="margin-top:8px;">
        현재 설정: <b id="mixLabel">기본 균형형</b>
        · easy <b id="mixEasy">20</b>% · medium <b id="mixMid">60</b>% · hard <b id="mixHard">20</b>%
      </div>

      <details class="mix-advanced">
        <summary>
          <span class="sum-title">⚙️ 고급 비율</span>
          <span class="sum-values" id="mixSummaryText">
            easy <b id="mixEasy">20</b>% · medium <b id="mixMid">60</b>% · hard <b id="mixHard">20</b>%
          </span>
          <span class="sum-hint">조절</span>
        </summary>

        <div class="mix-sliders">
          <div class="mix-row">
            <div class="label">easy</div>
            <input type="range" id="mixEasyRange" min="0" max="100" value="20" />
            <div class="value"><span id="mixEasyV">20</span>%</div>
          </div>

          <div class="mix-row">
            <div class="label">medium</div>
            <input type="range" id="mixMidRange" min="0" max="100" value="60" />
            <div class="value"><span id="mixMidV">60</span>%</div>
          </div>

          <div class="mix-row">
            <div class="label">hard</div>
            <input type="range" id="mixHardRange" min="0" max="100" value="20" />
            <div class="value"><span id="mixHardV">20</span>%</div>
          </div>

          <!-- 서버로 보낼 커스텀 값 -->
          <input type="hidden" name="mix_easy" id="mixEasyInput" value="20" />
          <input type="hidden" name="mix_mid"  id="mixMidInput"  value="60" />
          <input type="hidden" name="mix_hard" id="mixHardInput" value="20" />

          <div class="muted">
            ※ 고급 설정을 건드리면 자동으로 <b>커스텀</b>으로 전환됩니다. (합계는 100%로 자동 보정)
          </div>
        </div>
      </details>
    </div>

    <div>
      <label class="muted">단원 선택(복수)</label>
      <div class="unitlist" id="unitList">
        <div class="muted">학년/과목 선택 후 단원 목록을 불러옵니다…</div>
      </div>
      <div class="muted" style="margin-top:6px;">✅ 체크된 단원들의 승인 문항만 추출됩니다.</div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <button class="btn primary" type="submit">학습지 생성</button>
      <a class="btn" href="{{ url_for('home') }}">홈</a>
    </div>
  </form>
</div>

<script>
  const GRADES = {{ GRADES|tojson }};
  const SUBJECT_GROUPS = {{ SUBJECT_GROUPS|tojson }};
  const HIGH_SUBJECTS = {{ HIGH_SUBJECTS|tojson }};
  const MIDDLE_SUBJECTS = {{ MIDDLE_SUBJECTS|tojson }};

  const gradeInput = document.getElementById("gradeInput");
  const sgInput = document.getElementById("sgInput");
  const gradeChips = document.getElementById("gradeChips");
  const sgChips = document.getElementById("sgChips");
  const subSel = document.getElementById("subSubjectSel");
  const unitList = document.getElementById("unitList");

  function isHigh(g){ return (g||"").startsWith("고"); }

  function makeChips(container, items, defaultValue, onPick){
    container.innerHTML = "";
    items.forEach(v=>{
      const b = document.createElement("button");
      b.type = "button";
      b.className = "chip" + (v===defaultValue ? " active" : "");
      b.textContent = v;
      b.addEventListener("click", ()=>{
        [...container.querySelectorAll(".chip")].forEach(x=>x.classList.remove("active"));
        b.classList.add("active");
        onPick(v);
      });
      container.appendChild(b);
    });
  }

  function fillSubSubjects(){
    const g = gradeInput.value;
    const sg = sgInput.value;
    subSel.innerHTML = '<option value="">(선택)</option>';

    const data = isHigh(g) ? HIGH_SUBJECTS : MIDDLE_SUBJECTS;
    (data[sg] || []).forEach(v=>{
      const o = document.createElement("option");
      o.value = v; o.textContent = v;
      subSel.appendChild(o);
    });
  }

  // ✅ 커리큘럼 기반 단원 체크박스 렌더링(대단원/소단원)
  function renderUnits(){
    if (!window.getCurriculumBlocks || !window.formatUnitValue) {
      unitList.innerHTML = '<div class="muted">curriculum.js를 불러오지 못했습니다.</div>';
      return;
    }

    const g = gradeInput.value;
    const sg = sgInput.value;
    const ss = (subSel.value || "").trim();

    const blocks = window.getCurriculumBlocks(g, sg, ss);

    if (!blocks.length){
      unitList.innerHTML = '<div class="muted">커리큘럼에 단원이 없습니다. (static/curriculum.js를 채워주세요)</div>';
      return;
    }

    unitList.innerHTML = "";

    blocks.forEach(block=>{
      // 대단원 제목
      const big = document.createElement("div");
      big.style.fontWeight = "900";
      big.style.margin = "10px 0 6px";
      big.textContent = block.big;
      unitList.appendChild(big);

      const smalls = Array.isArray(block.small) ? block.small : [];
      if (!smalls.length) {
        // 소단원이 없으면 "대단원만" 선택 가능하게 처리
        const row = document.createElement("label");
        row.className = "unititem";
        const v = window.formatUnitValue(block.big, "");
        row.innerHTML = `<input type="checkbox" name="units" value="${v.replaceAll('"','&quot;')}"> <span>${block.big}</span>`;
        unitList.appendChild(row);
        return;
      }

      smalls.forEach(s=>{
        const row = document.createElement("label");
        row.className = "unititem";
        row.style.marginLeft = "10px";
        const v = window.formatUnitValue(block.big, s);
        row.innerHTML = `<input type="checkbox" name="units" value="${v.replaceAll('"','&quot;')}"> <span>${s}</span>`;
        unitList.appendChild(row);
      });
    });
  }

  // ===== 난이도 믹스(프리셋 + 커스텀) =====
const MIX_PRESETS = [
  { key:"review",    label:"개념 복습형", e:50, m:40, h:10 },
  { key:"balanced",  label:"기본 균형형", e:20, m:60, h:20 },
  { key:"exam",      label:"실전 대비형", e:10, m:50, h:40 },
  { key:"challenge", label:"도전형(고난도)", e:5, m:25, h:70 },
];

const mixMode = document.getElementById("mixMode");
const mixPresetChips = document.getElementById("mixPresetChips");
const mixPresetInput = document.getElementById("mixPresetInput");

const mixLabel = document.getElementById("mixLabel");
const mixEasy = document.getElementById("mixEasy");
const mixMid  = document.getElementById("mixMid");
const mixHard = document.getElementById("mixHard");

const mixEasyRange = document.getElementById("mixEasyRange");
const mixMidRange  = document.getElementById("mixMidRange");
const mixHardRange = document.getElementById("mixHardRange");

const mixEasyInput = document.getElementById("mixEasyInput");
const mixMidInput  = document.getElementById("mixMidInput");
const mixHardInput = document.getElementById("mixHardInput");

function setMixDisplay(label, e, m, h){
  mixLabel.textContent = label;

  // summary용(프리셋 영역의 현재 설정 표시)
  mixEasy.textContent = String(e);
  mixMid.textContent  = String(m);
  mixHard.textContent = String(h);

  // ✅ 고급 비율 바(요약 텍스트)도 같이 업데이트
  const summary = document.getElementById("mixSummaryText");
  if (summary) summary.textContent = `easy ${e}% · medium ${m}% · hard ${h}%`;

  // 고급 영역 오른쪽 값 표시
  const ev = document.getElementById("mixEasyV");
  const mv = document.getElementById("mixMidV");
  const hv = document.getElementById("mixHardV");
  if (ev) ev.textContent = String(e);
  if (mv) mv.textContent = String(m);
  if (hv) hv.textContent = String(h);

  // 고급 슬라이더/hidden도 동기화
  mixEasyRange.value = e; mixMidRange.value = m; mixHardRange.value = h;
  mixEasyInput.value = e; mixMidInput.value = m; mixHardInput.value = h;
}



function normalizeTo100(e, m, h){
  e = Math.max(0, parseInt(e||0,10));
  m = Math.max(0, parseInt(m||0,10));
  h = Math.max(0, parseInt(h||0,10));
  let s = e+m+h;
  if (s <= 0) return {e:20,m:60,h:20};
  e = Math.round(e*100/s);
  m = Math.round(m*100/s);
  h = 100 - e - m;
  if (h < 0){
    const take = Math.min(m, -h);
    m -= take;
    h += take;
  }
  while (e+m+h < 100) m += 1;
  while (e+m+h > 100 && m>0) m -= 1;
  return {e,m,h};
}

function renderMixPresetChips(){
  mixPresetChips.innerHTML = "";
  MIX_PRESETS.forEach(p=>{
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip" + (p.key === mixPresetInput.value ? " active" : "");
    b.textContent = p.label;
    b.addEventListener("click", ()=>{
      [...mixPresetChips.querySelectorAll(".chip")].forEach(x=>x.classList.remove("active"));
      b.classList.add("active");
      mixMode.value = "preset";
      mixPresetInput.value = p.key;
      setMixDisplay(p.label, p.e, p.m, p.h);
    });
    mixPresetChips.appendChild(b);
  });
}

function onCustomMixChanged(){
  // 고급을 건드리면 커스텀 모드로
  mixMode.value = "custom";
  [...mixPresetChips.querySelectorAll(".chip")].forEach(x=>x.classList.remove("active"));
  mixPresetInput.value = "balanced"; // 의미 없지만 값 유지

  const n = normalizeTo100(mixEasyRange.value, mixMidRange.value, mixHardRange.value);

  // ✅ 모든 텍스트/요약/오른쪽값/hidden/range 동기화를 setMixDisplay가 책임지게
  setMixDisplay("커스텀", n.e, n.m, n.h);

  // ✅ range 값 자체도 정규화된 값으로 “고정” (합 100 유지)
  mixEasyRange.value = n.e;
  mixMidRange.value  = n.m;
  mixHardRange.value = n.h;
}

// ✅ input + change 둘 다 걸어야 휠/키보드/포커스 변경 케이스 커버됨
["input", "change"].forEach(evt=>{
  mixEasyRange.addEventListener(evt, onCustomMixChanged);
  mixMidRange.addEventListener(evt, onCustomMixChanged);
  mixHardRange.addEventListener(evt, onCustomMixChanged);
});


  // 초기: 기본 균형형
  renderMixPresetChips();
  setMixDisplay("기본 균형형", 20, 60, 20);


  makeChips(gradeChips, GRADES, "중1", (v)=>{ gradeInput.value=v; fillSubSubjects(); renderUnits(); });
  makeChips(sgChips, SUBJECT_GROUPS, "사회", (v)=>{ sgInput.value=v; fillSubSubjects(); renderUnits(); });

  subSel.addEventListener("change", renderUnits);

  fillSubSubjects();
  renderUnits();
</script>
"""


WORKSHEET_RESULT_HTML = """
<div class="card">
  <h2 style="margin:0 0 10px;">학습지 결과</h2>
  <div class="muted">
    <span class="pill">{{ grade }}</span>
    <span class="pill">{{ subject_group }}</span>
    {% if sub_subject %}<span class="pill">{{ sub_subject }}</span>{% endif %}
    <span class="pill">성향: {{ mix_label }}</span>
    <span class="pill">easy {{ e_pct }}%</span>
    <span class="pill">medium {{ m_pct }}%</span>
    <span class="pill">hard {{ h_pct }}%</span>
  </div>
  <div class="muted" style="margin-top:6px;">
    선택 단원: {{ units|join(", ") }}
  </div>
  <div class="muted" style="margin-top:6px;">
    추출 구성(대략): 쉬움 {{ qe }} / 중간 {{ qm }} / 어려움 {{ qh }} (총 {{ items|length }}문항)
  </div>

  <hr style="border:none;border-top:1px solid #eee;margin:14px 0;" />

  {% for q in items %}
    <div style="padding:12px 0;border-bottom:1px dashed #ddd;">
      <div style="font-weight:900;">{{ loop.index }}.</div>
      <div class="muted" style="margin-top:4px;">
        <span class="pill">ID {{ q.id }}</span>
        <span class="pill">{{ q.unit }}</span>
        <span class="pill">Lv{{ q.difficulty_level }}</span>
        <span class="pill">{{ q.qtype }}</span>
      </div>

      <div class="qbox" style="margin-top:8px;">{{ q.question }}</div>

      {% if q.qtype == "mcq" and q.choices_list %}
        <div style="margin-top:10px; padding:10px; border:1px solid #eee; border-radius:10px; background:#fafafa;">
          <div style="font-weight:800; margin-bottom:6px;">보기</div>
          <ol style="margin:0; padding-left:18px;">
            {% for c in q.choices_list %}
              <li style="margin:4px 0;">{{ c }}</li>
            {% endfor %}
          </ol>
        </div>
      {% endif %}

      {% if q.image_filename %}
        <div class="imgbox">
          <img src="{{ url_for('qimg', filename=q.image_filename) }}" alt="question image"/>
        </div>
      {% endif %}

      <details style="margin-top:10px;">
        <summary>정답 보기</summary>
        <div class="qbox" style="margin-top:8px;">
          <b>정답:</b> {{ q.answer }}
          {% if q.solution %}
            <div style="margin-top:8px;"><b>해설/메모:</b> {{ q.solution }}</div>
          {% endif %}
        </div>
      </details>
    </div>
  {% endfor %}

  <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;">
    <a class="btn primary" href="{{ url_for('worksheet') }}">다시 만들기</a>
    <a class="btn" href="{{ url_for('home') }}">홈</a>
  </div>
</div>
"""


# ============================================================
# Main
# ============================================================
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(host="127.0.0.1", port=5006, debug=True)
